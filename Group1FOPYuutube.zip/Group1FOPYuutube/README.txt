Welcome to Yuutube project!

- Yuutube (Netbean Project Folder)
- WIX1002 Managerial Report Group 1 OCC5 (Managerial Report)
- WIX1002 Technical Report Group 1 OCC5 (Technical Report)
- yuutube.sql (SQL File)

Things to install before running this program
- Netbean IDE 12.1
- mysql-connector-java-8.0.22.jar
- JDK 15

Things to do after installing everything

database setup
- Start xampp (apache and mysql)
- press admin at MySQL and direct u to localhost
- create a new table name yuutube
- import the database(yuutube.sql) into it
- done setting up database

netbean
-open project using netbean(Yuutube project)
-import library to library file(after import into yuutube project) JDK 15 and mysql connector

THE END!
The yuutube project will work now!

If cannot work feel free to whatsapp me (TEH 014-6693582)

People who involve this project
- Teh
- Patricia
- Shan Hong
- Alif
- Ee Wern